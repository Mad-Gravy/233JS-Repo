// Joseph Teague, 4/16/25

class Player {
    // declare private instance variables (aka fields)
    #name
    #number // player number
    #roundScore
    #savedDice = [];
    #rollCount = 0;

    constructor(name) {
        this.#name = name;
        this.#number = 0;
        this.#roundScore = 0;
    }

    // Getters
    get name() { return this.#name; }
    get number() { return this.#number; }
    get roundScore() { return this.#roundScore; }
    get savedDice() { return this.#savedDice; }
    get rollCount() { return this.#rollCount; }

    // Setters
    set number(value) { this.#number = value; }
    set roundScore(value) { this.#roundScore = value; }

    // Safely increment roll count
    incrementRollCount() {
        this.#rollCount++;
    }

    // Reset player state between rounds or games
    resetTurn() {
        this.#savedDice = [];
        this.#rollCount = 0;
        this.#roundScore = 0;
    }

}
