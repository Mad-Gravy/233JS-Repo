// Joseph Teague, 4/16/25

// Global constants
const NUMBER_OF_DIE = 5;
const NUMBER_OF_SIDES = 6;

let shipCptCrew = new Game();

