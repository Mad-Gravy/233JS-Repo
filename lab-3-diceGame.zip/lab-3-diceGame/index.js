// Joseph Teague, 4/16/25

// Set global constants for number of dice and sides
const NUMBER_OF_DIE = 5;
const NUMBER_OF_SIDES = 6;

// Create a new Game instance to start the app
let shipCptCrew = new Game();
// ask Prof. Bird about this code in multiple files